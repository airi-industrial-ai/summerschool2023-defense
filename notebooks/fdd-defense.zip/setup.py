from setuptools import find_packages, setup

setup(
    name='fdd-defense',
    packages=find_packages(),
    version='0.0.1',
    description='Defense of adversarial attacks on FDD models',
    url='https://github.com/airi-industrial-ai/fdd-defense',
    author='AIRI, Industrial AI',
    install_requires=[
        'torch', 
        'pandas', 
        'scikit-learn',
        'tqdm',
        'fddbenchmark @ git+https://github.com/airi-industrial-ai/fddbenchmark',
        'pytest',
    ],
)