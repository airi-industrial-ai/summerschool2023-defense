from inspect import getmembers, isclass
from fdd_defense.models import MLP
from fdd_defense import attacks
from fddbenchmark import FDDDataset, FDDDataloader
from sklearn.preprocessing import minmax_scale
import numpy as np
import pytest
import torch

fdd_attacks = [f[1] for f in getmembers(attacks, isclass)]

class TestOnSmallTEP:
    def setup_class(self):
        self.dataset = FDDDataset(name='small_tep')
        self.dataset.df[:] = minmax_scale(self.dataset.df)
        self.eps = 0.01
        dataloader = FDDDataloader(
            dataframe=self.dataset.df,
            mask=self.dataset.train_mask,
            labels=self.dataset.labels, 
            window_size=10, 
            step_size=1, 
            minibatch_training=True, 
            batch_size=10,
        )
        for ts, _, label in dataloader:
            break
        self.ts = ts
        self.label = label.values
        
    @pytest.mark.parametrize("attack", fdd_attacks)
    def test_base(self, attack):
        torch.manual_seed(0)
        np.random.seed(0)
        fddmodel = MLP(window_size=10, step_size=1, is_test=True)
        fddmodel.fit(self.dataset)
        fdd_attack = attack(fddmodel, eps=self.eps)
        adv_ts = fdd_attack.attack(self.ts, self.label)
        assert np.all(np.abs(self.ts - adv_ts) <= self.eps + 1e-7)
