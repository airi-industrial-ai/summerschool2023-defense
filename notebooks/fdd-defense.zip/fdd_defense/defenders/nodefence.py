from fdd_defense.defenders.base import BaseDefender


class NoDefenceDefender(BaseDefender):
    def __init__(self, fddmodel):
        super().__init__(fddmodel)
