import numpy as np
from fdd_defense.defenders.base import BaseDefender


class QuantizationDefender(BaseDefender):
    def __init__(self, fddmodel, qbit=8):
        super().__init__(fddmodel)
        self.qbit = qbit
    
    def predict(self, ts: np.ndarray):
        def_ts = np.floor(ts * 2**self.qbit) / 2**self.qbit
        return self.fddmodel.predict(def_ts)
