import numpy as np
from fdd_defense.defenders.base import BaseDefender
from fdd_defense.attacks import FGSMAttack
from fdd_defense.utils import weight_reset
from tqdm.auto import tqdm, trange
import torch


class AdversarialTrainingDefender(BaseDefender):
    def __init__(self, fddmodel, attack=None, lambd=1):
        super().__init__(fddmodel)
        if attack is None:
            attack = FGSMAttack(fddmodel, eps=0.01)
        self.attack = attack
        self.lambd = lambd
        self.fddmodel.model.apply(weight_reset)

        print('Adversarial training...')
        for e in trange(self.fddmodel.num_epochs, desc='Epochs ...'):
            losses = []
            for ts, _, label in tqdm(self.fddmodel.dataloader, desc='Steps ...', leave=False):
                batch_size = ts.shape[0]
                adv_ts = self.attack.attack(ts, label.values)
                adv_ts = torch.FloatTensor(adv_ts).to(self.fddmodel.device)
                label = torch.LongTensor(label.values).to(self.fddmodel.device)
                ts = torch.FloatTensor(ts).to(self.fddmodel.device)
                _ts = torch.cat([ts, adv_ts])
                _logits = self.fddmodel.model(_ts)
                logits = _logits[:batch_size]
                adv_logits = _logits[batch_size:]
                real_loss = self.fddmodel.loss_fn(logits, label)
                adv_loss = self.fddmodel.loss_fn(adv_logits, label)
                loss = real_loss + self.lambd * adv_loss
                self.fddmodel.optimizer.zero_grad()
                loss.backward()
                self.fddmodel.optimizer.step()
                losses.append(loss.item())
                if self.fddmodel.is_test:
                    break
            print(f'Epoch {e+1}, Loss: {sum(losses) / len(losses):.4f}')
