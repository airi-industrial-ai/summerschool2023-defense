from abc import ABC, abstractmethod
import numpy as np


class BaseDefender(ABC):  
    @abstractmethod
    def __init__(self, fddmodel: object):
        self.fddmodel = fddmodel
        pass
    
    def predict(self, ts: np.ndarray):
        return self.fddmodel.predict(ts)
