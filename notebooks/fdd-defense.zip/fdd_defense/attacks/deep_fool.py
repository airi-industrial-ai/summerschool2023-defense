"""
The implementation is adopted from
https://github.com/BorealisAI/advertorch
"""

from fdd_defense.attacks.base import BaseAttack
import torch
import numpy as np


def _batch_clamp_tensor_by_vector(vector, batch_tensor):
    return torch.min(
        torch.max(batch_tensor.transpose(0, -1), -vector), vector
    ).transpose(0, -1).contiguous()


def batch_clamp(float_or_vector, tensor):
    if isinstance(float_or_vector, torch.Tensor):
        assert len(float_or_vector) == len(tensor)
        tensor = _batch_clamp_tensor_by_vector(float_or_vector, tensor)
        return tensor
    elif isinstance(float_or_vector, float):
        tensor = torch.clamp(tensor, -float_or_vector, float_or_vector)
    else:
        raise TypeError("Value has to be float or torch.Tensor")
    return tensor


class DeepfoolLinfAttack(BaseAttack):
    """
    A simple and fast gradient-based adversarial attack.
    Seyed-Mohsen Moosavi-Dezfooli, Alhussein Fawzi, Pascal Frossard,
    "DeepFool: a simple and accurate method to fool deep neural
    networks", https://arxiv.org/abs/1511.04599

    :param model: forward pass function.
    :param num_classes: number of classes considered
    :param num_steps: number of iterations.
    :eps=0.1
    :param clip_min: mininum value per input dimension.
    :param clip_max: maximum value per input dimension.
    """

    def __init__(
            self, 
            model: object, 
            eps: float,
            num_steps: int=50,
            clip_min=0.,
            clip_max=1.,
        ):
        super().__init__(model, eps)
        self.num_classes = len(set(model.dataset.labels))
        self.num_steps = num_steps
        self.clip_min = clip_min
        self.clip_max = clip_max

    def is_adv(self, logits, y):
        # criterion
        y_hat = logits.argmax(-1)
        is_adv = y_hat != y
        return is_adv

    def get_deltas_logits(self, x, k, classes):
        # definition of loss_fn
        N = len(classes)
        rows = range(N)
        i0 = classes[:, 0]

        logits = self.model(x)
        ik = classes[:, k]
        l0 = logits[rows, i0]
        lk = logits[rows, ik]
        delta_logits = lk - l0

        return {'sum_deltas': delta_logits.sum(),
                'deltas': delta_logits,
                'logits': logits}

    def get_grads(self, x, k, classes):
        deltas_logits = self.get_deltas_logits(x, k, classes)
        deltas_logits['sum_deltas'].backward()
        deltas_logits['grads'] = x.grad.clone()
        x.grad.data.zero_()
        return deltas_logits

    def get_distances(self, deltas, grads):
        return abs(deltas) / (
            grads.flatten(start_dim=2, end_dim=-1).abs().sum(axis=-1) + 1e-8)

    def get_perturbations(self, distances, grads):
        return self.atleast_kd(distances, grads.ndim) * grads.sign()

    def atleast_kd(self, x, k):
        shape = x.shape + (1,) * (k - x.ndim)
        return x.reshape(shape)

    def _verify_and_process_inputs(self, x, y):
        x = x.detach().clone().requires_grad_()
        y = y.detach().clone()
        return x, y

    def attack(self, x, y):
        super().attack(x, y)
        x = torch.FloatTensor(x).to(self.model.device)
        y = torch.LongTensor(y).to(self.model.device)
        x, y = self._verify_and_process_inputs(x, y)
        x.requires_grad_()

        logits = self.model(x)

        # get the classes
        classes = logits.argsort(axis=-1).flip(-1).detach()
        if self.num_classes is None:
            self.num_classes = logits.shape[-1]
        else:
            self.num_classes = min(self.num_classes, logits.shape[-1])

        N = len(x)
        rows = range(N)

        x0 = x
        p_total = torch.zeros_like(x)
        for _ in range(self.num_steps):
            # let's first get the logits using k = 1 to see if we are done
            diffs = [self.get_grads(x, 1, classes)]

            is_adv = self.is_adv(diffs[0]['logits'], y)
            #if is_adv.all():
            #    break

            diffs += [self.get_grads(x, k, classes) for k in range(2, self.num_classes)] # noqa

            deltas = torch.stack([d['deltas'] for d in diffs], dim=-1)
            grads = torch.stack([d['grads'] for d in diffs], dim=1)

            # calculate the distances
            # compute f_k / ||w_k||
            distances = self.get_distances(deltas, grads)

            # determine the best directions
            best = distances.argmin(axis=1)  # compute \hat{l}
            distances = distances[rows, best]
            deltas = deltas[rows, best]
            grads = grads[rows, best]

            # apply perturbation
            distances = distances + 1e-4  # for numerical stability
            p_step = self.get_perturbations(distances, grads)  # =r_i

            p_total += p_step
            
            # don't do anything for those that are already adversarial
            p_total = torch.where(
                self.atleast_kd(is_adv, x.ndim),
                0,
                p_total
            )
            p_total = batch_clamp(self.eps, p_total)
            x = x0 + p_total
            x = torch.clamp(x, min=self.clip_min, max=self.clip_max).clone().detach().requires_grad_()

        x = x.detach().cpu().numpy()
        return x
