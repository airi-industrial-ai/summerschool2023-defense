from fdd_defense.attacks.base import BaseAttack


class NoAttack(BaseAttack):  
    def attack(self, ts, label):
        super().attack(ts, label)
        return ts
