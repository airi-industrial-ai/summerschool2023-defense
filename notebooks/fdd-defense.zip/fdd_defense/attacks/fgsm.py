import numpy as np
from fdd_defense.attacks.base import BaseAttack


class FGSMAttack(BaseAttack):  
    def attack(self, ts, label):
        super().attack(ts, label)
        grad = self.model.get_grad(ts, label)
        return ts + self.eps * np.sign(grad)
