"""
The implementation is adopted from
https://github.com/Harry24k/adversarial-attacks-pytorch
"""

from fdd_defense.attacks.base import BaseAttack
import torch
import torch.nn as nn
from torch.optim import Adam
import numpy as np

class CarliniWagnerAttack(BaseAttack):
    def __init__(
            self, 
            model: object, 
            eps: float, 
            num_steps: int=10,
        ):
        super().__init__(model, eps)
        self.num_steps = num_steps

    def attack(self, _ts: np.ndarray, label: np.ndarray) -> np.ndarray:
        super().attack(_ts, label)
        ts = torch.FloatTensor(_ts).clone().detach()
        label = torch.LongTensor(label).clone().detach()
        w = self.inverse_tanh_space(ts).detach()
        w.requires_grad = True

        best_adv_ts = ts.clone().detach()
        best_L2 = 1e10*torch.ones((len(ts)))
        dim = len(ts.shape)

        MSELoss = nn.MSELoss(reduction='none')
        Flatten = nn.Flatten()

        optimizer = Adam([w], lr=0.01)

        for _ in range(self.num_steps):
            adv_ts = self.tanh_space(w)
            current_L2 = MSELoss(Flatten(adv_ts), Flatten(ts)).sum(dim=1)
            L2_loss = current_L2.sum()

            outputs = self.model(adv_ts)
            f_loss = self.f(outputs, label).sum()

            cost = L2_loss + f_loss

            optimizer.zero_grad()
            cost.backward()
            optimizer.step()

            pre = torch.argmax(outputs.detach(), 1)
            condition = (pre != label).float()

            mask = condition*(best_L2 > current_L2.detach())
            best_L2 = mask*current_L2.detach() + (1-mask)*best_L2

            mask = mask.view([-1]+[1]*(dim-1))
            best_adv_ts = mask*adv_ts.detach() + (1-mask)*best_adv_ts

        best_adv_ts = best_adv_ts.cpu().numpy()
        best_adv_ts = np.clip(best_adv_ts, a_min=_ts-self.eps, a_max=_ts+self.eps)
        return best_adv_ts

    def tanh_space(self, x):
        return 1/2*(torch.tanh(x) + 1)

    def inverse_tanh_space(self, x):
        # torch.atanh is only for torch >= 1.7.0
        # atanh is defined in the range -1 to 1
        return self.atanh(torch.clamp(x*2-1, min=-1, max=1))

    def atanh(self, x):
        return 0.5*torch.log((1+x)/(1-x))

    # f-function in the paper
    def f(self, outputs, label):
        one_hot_label = torch.eye(outputs.shape[1])[label]
        # find the max logit other than the target class
        other = torch.max((1-one_hot_label)*outputs, dim=1)[0]
        # get the target class's logit
        real = torch.max(one_hot_label*outputs, dim=1)[0]
        return torch.clamp((real-other), min=0)
