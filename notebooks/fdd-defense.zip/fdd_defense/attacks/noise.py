from fdd_defense.attacks.base import BaseAttack
import numpy as np


class NoiseAttack(BaseAttack):   
    def attack(self, ts, label):
        delta = self.eps * np.sign(np.random.uniform(-self.eps, self.eps))
        return ts + delta
